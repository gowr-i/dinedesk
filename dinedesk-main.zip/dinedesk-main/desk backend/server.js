const http = require("http");
const url = require("url");
const fs = require("fs");
const path = require("path");

const DATA_FILE = path.join(__dirname, "orders.json");

// ===== Load Existing Orders =====
let orders = [];

function loadOrders() {
  if (fs.existsSync(DATA_FILE)) {
    const data = fs.readFileSync(DATA_FILE);
    orders = JSON.parse(data);
  }
}

function saveOrders() {
  fs.writeFileSync(DATA_FILE, JSON.stringify(orders, null, 2));
}

loadOrders();

let currentId = orders.length > 0
  ? Math.max(...orders.map(o => o.id)) + 1
  : 1;

const server = http.createServer((req, res) => {
  const parsedUrl = url.parse(req.url, true);
  const method = req.method;

  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "GET, POST, PUT, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");

  if (method === "OPTIONS") {
    res.writeHead(200);
    res.end();
    return;
  }

  // ===== Serve Static Files =====
  if (
    req.url === "/" ||
    req.url.endsWith(".html") ||
    req.url.endsWith(".css") ||
    req.url.endsWith(".js") ||
    req.url.endsWith(".png")
  ) {
    const filePath =
      req.url === "/"
        ? path.join(__dirname, "index.html")
        : path.join(__dirname, req.url);

    const ext = path.extname(filePath);

    const contentType = {
      ".html": "text/html",
      ".css": "text/css",
      ".js": "text/javascript",
      ".png": "image/png"
    };

    fs.readFile(filePath, (err, content) => {
      if (err) {
        res.writeHead(404);
        res.end("File not found");
      } else {
        res.writeHead(200, {
          "Content-Type": contentType[ext] || "text/plain"
        });
        res.end(content);
      }
    });

    return;
  }

  // ===== CREATE ORDER =====
  if (method === "POST" && parsedUrl.pathname === "/orders") {
    let body = "";

    req.on("data", chunk => {
      body += chunk;
    });

    req.on("end", () => {
      const data = JSON.parse(body);

      const newOrder = {
        id: currentId++,
        customerName: data.customerName,
        tableNumber: data.tableNumber,
        items: data.items,
        total: data.total,
        tax: 0,
        tip: 0,
        paymentMethod: null,
        paymentStatus: "Pending"
      };

      orders.push(newOrder);
      saveOrders(); // ✅ SAVE TO FILE

      res.writeHead(200, { "Content-Type": "application/json" });
      res.end(JSON.stringify(newOrder));
    });

    return;
  }

  // ===== GET ALL ORDERS =====
  if (method === "GET" && parsedUrl.pathname === "/orders") {
    res.writeHead(200, { "Content-Type": "application/json" });
    res.end(JSON.stringify(orders));
    return;
  }

  // ===== PAY ORDER =====
  if (method === "PUT" && parsedUrl.pathname.startsWith("/orders/")) {
    const id = parseInt(parsedUrl.pathname.split("/")[2]);

    let body = "";
    req.on("data", chunk => {
      body += chunk;
    });

    req.on("end", () => {
      const data = JSON.parse(body);
      const order = orders.find(o => o.id === id);

      if (!order) {
        res.writeHead(404);
        res.end("Order not found");
        return;
      }

      order.tax = data.tax;
      order.tip = data.tip;
      order.total = data.total;
      order.paymentMethod = data.paymentMethod;
      order.paymentStatus = "Paid";

      saveOrders(); // ✅ SAVE UPDATE

      res.writeHead(200, { "Content-Type": "application/json" });
      res.end(JSON.stringify(order));
    });

    return;
  }

  res.writeHead(404);
  res.end("Not Found");
});

server.listen(5000, () => {
  console.log("Server running at http://localhost:5000");
});
